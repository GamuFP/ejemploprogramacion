package com.practica;

import java.util.Objects;
import java.util.Scanner;


//Diferencia entre Double y OptionalDouble
// La clase Double es un wrapper del tipo primitivo double, 
// aporta metodos utiles para trabajar con doubles
//
// La clase OptionalDouble puede no contener un double, es decir,
// estar vacia pero sin contener null, aporta metodos para trabajar 
// con la posibilidad de que haya o no un double
public class Uso {
	public static Scanner scan = new Scanner(System.in);
	public static final int NUM_ALUMNOS = 20;
	public static Alumno[] clase = new Alumno[NUM_ALUMNOS];
	public static int cuentaAlumnos = 0;
	public static boolean exit = true;

	public static void main(String[] args) {
		
		while (exit) {
			menuPrincipal();
		}
		System.out.println("Adios");

	}

	public static void menuPrincipal() {
		String pregunta = "�Qu� quieres hacer?";
		String[] opciones = { "Crear un alumno", "Poner notas a un alumno", "Sacar la media de un alumno","Imprimir el informe de un alumno", "Salir" };
		ConsoleMenu menu = new ConsoleMenu(pregunta, true, opciones);

		switch (menu.launchMenu()) {
		case 1:
			if (cuentaAlumnos >= NUM_ALUMNOS) {
				System.out.println("Por seguridad no se pueden meter mas alumnos en la clase");
				break;
			}
			clase[cuentaAlumnos] = new Alumno();
			cuentaAlumnos++;
			System.out.println("Alumno "+cuentaAlumnos+" a�adido");
			break;
		case 2:
			menuAddNotas();
			break;
		case 3:
			menuMedia();
			break;
		case 4:
			menuInforme();
			break;
		case 0:
			exit = false;
			menu.close();
			return;
		}

	}

	public static void menuAddNotas() {

		int alumno = getAlumno();
		// nextInt busca un int en el input y lo devuelve
		// Dejandose el \n que se crea al darle al enter
		scan.nextLine();
		// Comprobamos que el alumno existe
		if (!checkAlumno(alumno))
			return;
		
		// Si todo esta bien pedimos el trimestre y las notas
		String notas = "";
		String pregunta = "Seleccione a que trimestre quiere a�adir notas";
		String[] opciones = { "Primer trimestre", "Segundo trimestre", "Tercer trimestre" };
		ConsoleMenu menu = new ConsoleMenu(pregunta, opciones);
		int trimestre = menu.launchMenu();

		System.out.println("Introduce las notas que quieras meter separadas por comas (max "+clase[alumno].NUM_NOTAS+")");
		notas = scan.nextLine();

		clase[alumno].addNotas(trimestre, notas);
	}

	public static void menuMedia() {

		int alumno = getAlumno();
		// Comprobamos que el alumno existe
		if (!checkAlumno(alumno))
			return;

		String pregunta = "�De qu� trimestre quieres ver la media?";
		String[] opciones = { "Primer trimestre", "Segundo trimestre", "Tercer trimestre", "Todos los trimestres" };
		ConsoleMenu menu = new ConsoleMenu(pregunta, opciones);
		int opcion = menu.launchMenu();
		switch (opcion) {
		case 1, 2, 3:
			float mediaTrimestre = clase[alumno].getMedia(opcion);
			System.out.println("La media del trimestre " + opcion + " es " + mediaTrimestre +" - "+Alumno.calificar(mediaTrimestre) );
			break;
		case 4:
			float mediaTotal = clase[alumno].getMedia();
			System.out.println("La media del curso es " + mediaTotal +" - "+Alumno.calificar(mediaTotal));
		}

	}
	public static void menuInforme() {
		int numAlumno = getAlumno();
		// Comprobamos que el alumno existe
		if (!checkAlumno(numAlumno))
			return;
		Alumno alumno = clase[numAlumno];
		System.out.println("T_1\tT_2\tT_3");
		for(int i = 0; i < alumno.NUM_NOTAS; i++) {
			System.out.print(" ");
			System.out.print(alumno.trimestres[0][i]);
			System.out.print("\t ");
			System.out.print(alumno.trimestres[1][i]);
			System.out.print("\t ");
			System.out.println(alumno.trimestres[2][i]);
		}
	}
	public static int getAlumno() {
		System.out.println("�Qu� alumno quieres?");
		System.out.print("Alumnos: ");
		for(int i = 1; i <= cuentaAlumnos; i++) {
			System.out.print(i+" ");
		}
		System.out.println();
		return scan.nextInt() - 1;
	}

	public static boolean checkAlumno(int alumno) {
		// Comprobamos que el alumno existe
		if (alumno < 0 | alumno > NUM_ALUMNOS || Objects.isNull(clase[alumno])) {
			System.out.println("No existe ese alumno");
			return false;
		}
		return true;
	}
}
