package com.practica;

import java.util.Scanner;

/**
 * Permite crear menus por consola rapidamente
 * 
 * @author Campus FP
 *
 */
public class ConsoleMenu {
	private String pregunta;
	private String[] opciones;
	private boolean puedeVolver;

	private Scanner scan = new Scanner(System.in);

	/**
	 * Crea un nuevo menu con la pregunta y las opciones pasadas
	 * 
	 * @param pregunta
	 * @param opciones, como array o varios Strings sueltos
	 */
	public ConsoleMenu(String pregunta, String... opciones) {
		this.pregunta = pregunta;
		this.opciones = opciones;
		this.puedeVolver = false;
	}
	/**
	 * Crea un nuevo menu con la pregunta y las opciones pasadas
	 * 
	 * @param pregunta
	 * @param puedeVolver si es true el menu se formatea para que se pueda volver con el 0
	 * @param opciones, como array o varios Strings sueltos
	 */
	public ConsoleMenu(String pregunta, boolean puedeVolver, String... opciones) {
		this.pregunta = pregunta;
		this.opciones = opciones;
		this.puedeVolver = puedeVolver;
	}

	/**
	 * Ense�a el menu por consola y pide una respuesta
	 * 
	 * @return la opcion elegida
	 */
	public int launchMenu() {
		int opcion = -1;
		do {
			showMenu();
			opcion = getInput();
		} while (opcion < (puedeVolver ? 0 : 1)|| opcion > opciones.length - (puedeVolver ? 1 : 0));
		return opcion;
	}
	/**
	 * Ense�a el menu por consola
	 */
	private void showMenu() {
		int index = 0;
		System.out.println("=================================");
		System.out.println(pregunta);
		System.out.println("Elija una opci�n del " +(puedeVolver ? 0 : 1) +" al " + (opciones.length - (puedeVolver ? 1 : 0)));
		for (String opcion : opciones) {
			if (puedeVolver & ++index == opciones.length)
				System.out.println("0-" + opcion);
			else
				System.out.println(index + "-" + opcion);
		}
		System.out.println("=================================");
	}
	/**
	 * Pide una opcion por consola
	 * @return la opcion elegida en forma de int
	 */
	private int getInput() {
		String opcion = scan.nextLine();
		return parseOpcion(opcion);
	}
	/**
	 * Parsea la opcion pasada para que sea un int
	 * @param opcion
	 * @return int
	 */
	private static int parseOpcion(String opcion) {
		opcion = opcion.replaceAll("[^0-9]", "");
		if (opcion == "")
			return -1;
		return Integer.parseInt(opcion);
	}
	/**
	 * Cierra todos los recursos usados
	 */
	public void close() {
		scan.close();
	}

}
