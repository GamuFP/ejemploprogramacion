package com.practica;

import java.util.Arrays;

public class Alumno {
	
	public int[][] trimestres;
	public final int NUM_NOTAS = 6;
	public static final int[] VACIO = {0,0,0,0,0,0}; 
	
	public Alumno() {
		trimestres = new int[3][NUM_NOTAS];
	}
	public void addNotas(int trimestre, String notas) {
		int[] parsedNotas = parseNotas(notas);

		//Compueba que se hayan pasado menos de 6 notas (Guard Clause)
		if (parsedNotas.length > trimestres[0].length) {
			System.out.println("No se pueden a�adir tantas notas");
			return;
		}
		trimestres[trimestre-1] = parsedNotas;
	}
	private int[] parseNotas(String notas) {
	//Preprocesa el String:
	//	Cambia los caracteres que no sean numeros por 1 solo espacio
	//	Elimina los espacios delante y detras del String
	//	Separa el String por los espacios
		String[] arrayPreprocesado = notas
				.replaceAll("[^0-9]{1,}", " ")
				.trim()
				.split(" ");
	//En el caso en que no se introduzcan notas
		if (arrayPreprocesado.length <= 1) return VACIO;
	//Convierte ese array preprocesado de String[] a int[]
		return Arrays.stream(arrayPreprocesado)
				.mapToInt(x -> Integer.parseInt(x))
				.toArray();
	}
	public float getMedia(int trimestre) {

		return Arrays.stream(trimestres[trimestre-1]).sum() / (float)NUM_NOTAS;
	}
	public float getMedia() {
		return (getMedia(1) + getMedia(2) + getMedia(3)) / 3f;
	}
	public static String calificar(float nota) {
		if(nota < 5) return "suspenso";
		else if (nota < 7) return "bien";
		else if (nota < 9) return "notable";
		else return "sobresaliente";
	}
	

}